package com.flyingdigital;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.security.UserGroupInformation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 * cdh hbase kerberos认证
 */
public class Demo {

    private static final String IP = "172.19.5.112";
    private static final String PORT = "2181";
    private static final String USERNAME = "hbase/quickstart.cloudera@CDH.COM";

    private static final boolean isKerberos = true;
    private static final String KEYTAB_PATH = "D:\\一些资料\\github\\hbaseDemo\\conf\\hbase.keytab";
    private static final String KRB5_PATH = "D:\\一些资料\\github\\hbaseDemo\\conf\\krb5.conf";
    private static final String MASTER_PRINCIPAL = "hbase/quickstart.cloudera@CDH.COM";
    private static final String REGION_PRINCIPAL = "hbase/quickstart.cloudera@CDH.COM";



    private static final String JAVA_KRB5_CONF = "java.security.krb5.conf";
    private static final String ZOOKEEPER_QUORUM = "hbase.zookeeper.quorum";
    private static final String ZOOKEEPER_PROPERTY_CLIENT_PORT = "hbase.zookeeper.property.clientPort";
    private static final String HBASE_CLIENT_RETRIES_NUMBER = "hbase.client.retries.number";
    private static final String HADOOP_SECURITY_AUTHENTICATION = "hadoop.security.authentication";
    private static final String HBASE_SECURITY_AUTHENTICATION = "hbase.security.authentication";
    private static final String HBASE_MASTER_KERBEROS_PRINCIPAL = "hbase.master.kerberos.principal";
    private static final String HBASE_REGIONSERVER_KERBEROS_PRINCIPAL = "hbase.regionserver.kerberos.principal";



    public static void main(String[] args) throws IOException {
        Connection connection = null;
        Admin admin = null;
        try {
            connection = getConnection();
            System.out.println("获取连接成功 ！");
            System.out.println(connection.getAdmin().tableExists(TableName.valueOf("sha256_StudentAndCourse-1")));
            System.out.println(Arrays.toString(connection.getAdmin().listTableNames()));
            System.out.println(Arrays.toString(connection.getAdmin().listTableNames()).contains("sha256_StudentAndCourse-1"));
//            connection.getAdmin().tableExists()
//
//            // 建表
//            admin = connection.getAdmin();
//            TableName tableName = TableName.valueOf("zq_test");
//
//            List<String> familyName = new ArrayList<>();
//            familyName.add("test1");
//
//            HTableDescriptor descriptor = new HTableDescriptor(TableName.valueOf("zq_test"));
//            for (String family:familyName) {
//                HColumnDescriptor hColumnDescriptor = new HColumnDescriptor(family);
//                descriptor.addFamily(hColumnDescriptor);
//            }
//            admin.createTable(descriptor);
//            System.out.println("建表成功");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (admin!=null){
                admin.close();
            }
            closeConnection(connection);
        }
    }

    /**
     * cdh hbase kerberos认证
     */
    public static Connection getConnection() throws IOException {

        javax.security.auth.login.Configuration.setConfiguration(null);

        Configuration conf = HBaseConfiguration.create();
        conf.set(ZOOKEEPER_QUORUM, IP);
        conf.set(ZOOKEEPER_PROPERTY_CLIENT_PORT, PORT);
        conf.set(HBASE_CLIENT_RETRIES_NUMBER, "3");

        if (isKerberos){
            System.setProperty(JAVA_KRB5_CONF, KRB5_PATH);
            conf.set(HADOOP_SECURITY_AUTHENTICATION, "kerberos");
            conf.set(HBASE_SECURITY_AUTHENTICATION, "kerberos");
            conf.set(HBASE_MASTER_KERBEROS_PRINCIPAL, MASTER_PRINCIPAL);
            conf.set(HBASE_REGIONSERVER_KERBEROS_PRINCIPAL, REGION_PRINCIPAL);
            UserGroupInformation.setConfiguration(conf);
            try {
                UserGroupInformation.loginUserFromKeytab(USERNAME, KEYTAB_PATH);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return ConnectionFactory.createConnection(conf);
    }


    public static void closeConnection(Connection connection){
        if (connection != null){
            try {
                connection.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
